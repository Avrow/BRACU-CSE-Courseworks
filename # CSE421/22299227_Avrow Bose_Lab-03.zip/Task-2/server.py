import socket

FORMAT = 'utf-8'
HEADER = 64

SERVER = socket.gethostbyname(socket.gethostname())
PORT = 6500
DISCONNECT_MSG = "End"
ADDR = (SERVER, PORT)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)
print("SERVER IS STARTING.............")

#Listening Stage
server.listen()
print("SERVER IS LISTENING ON", SERVER)

#Accepting Stage
while True:
    conn, addr = server.accept()
    print("CONNECTED TO", addr)
    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(FORMAT)
            if msg == DISCONNECT_MSG:
                connected = False
                conn.send(f"TERMINATING THE CONNECTION WITH {addr}".encode(FORMAT))

            else:
                vowels = "aeiouAEIOU"
                count = 0

                for ch in msg:
                    if ch in vowels:
                        count += 1

                if count == 0:
                    reply = "Not enough vowels"
                elif count <= 2:
                    reply = "Enough vowels I guess"
                else:
                    reply = "Too many vowels"

                conn.send(reply.encode(FORMAT))

    conn.close()