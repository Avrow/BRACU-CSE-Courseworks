import socket

FORMAT = 'utf-8'
HEADER = 64

SERVER = socket.gethostbyname(socket.gethostname())
PORT = 6500
DISCONNECT_MSG = "End"
ADDR = (SERVER, PORT)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)
print("SERVER IS STARTING.............")

#Listening Stage
server.listen()
print("SERVER IS LISTENING ON", SERVER)

#Accepting Stage
while True:
    conn, addr = server.accept()
    print("CONNECTED TO", addr)
    connected = True
    while connected:
        raw_len = conn.recv(HEADER).decode(FORMAT)
        if raw_len:
            length = int(raw_len)
            data = conn.recv(length).decode(FORMAT)

            if data == DISCONNECT_MSG:
                conn.send(f"TERMINATING THE CONNECTION WITH {addr}".encode(FORMAT))
                connected = False
                continue

            hours = int(data)
            if hours > 40:
                extra = hours - 40
                computed_salary = 8000 + extra * 300
            else:
                computed_salary = hours * 200

            reply = f"The salary is Tk {computed_salary}"
            conn.send(reply.encode(FORMAT))
    conn.close()