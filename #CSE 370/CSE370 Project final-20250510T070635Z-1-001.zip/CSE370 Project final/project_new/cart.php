<?php
session_start();
include("connect.php");

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$user_email = $_SESSION['email'];

// Handle remove request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_cart_id'])) {
    $remove_id = $_POST['remove_cart_id'];
    $delete = mysqli_query($conn, "DELETE FROM cart WHERE id = '$remove_id'");
}

// Fetch cart items
$query = mysqli_query($conn, "SELECT products.*, cart.id AS cart_id, cart.quantity 
                              FROM cart 
                              JOIN products ON cart.product_id = products.id 
                              WHERE cart.user_email = '$user_email'");
$total = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0fdf4;
            padding: 40px;
            margin: 0;
        }

        h1 {
            text-align: center;
            color: #065f46;
        }

        .cart-container {
            max-width: 900px;
            margin: auto;
            background-color: #ffffff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }

        .cart-item {
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid #e5e7eb;
            padding: 15px 0;
            align-items: center;
        }

        .cart-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            margin-right: 20px;
        }

        .cart-details {
            flex: 1;
        }

        .cart-details p {
            margin: 4px 0;
        }

        .remove-btn {
            background-color: #ef4444;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 6px;
            cursor: pointer;
        }

        .remove-btn:hover {
            background-color: #dc2626;
        }

        .grand-total {
            text-align: right;
            font-size: 18px;
            font-weight: bold;
            margin-top: 20px;
            color: #111827;
        }

        .place-order-btn {
            display: block;
            width: 100%;
            margin-top: 30px;
            padding: 15px;
            background-color: #10b981;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
        }

        .place-order-btn:hover {
            background-color: #059669;
        }

        .empty-message {
            text-align: center;
            color: #6b7280;
            margin-top: 50px;
        }
    </style>
</head>
<body>

<h1>Your Cart</h1>
<div class="cart-container">
    <?php if (mysqli_num_rows($query) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($query)): ?>
            <div class="cart-item">
                <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['product_name']; ?>">
                <div class="cart-details">
                    <h3><?php echo $row['product_name']; ?></h3>
                    <p>Price: ৳<?php echo $row['price']; ?></p>
                    <p>Quantity: <?php echo $row['quantity']; ?></p>
                </div>
                <form method="POST" action="cart.php">
                    <input type="hidden" name="remove_cart_id" value="<?php echo $row['cart_id']; ?>">
                    <button type="submit" class="remove-btn">Remove</button>
                </form>
            </div>
            <?php $total += $row['price'] * $row['quantity']; ?>
        <?php endwhile; ?>

        <div class="grand-total">Grand Total: ৳<?php echo $total; ?></div>

        <form action="payment.php" method="GET">
            <button type="submit" class="place-order-btn">Place to Order</button>
        </form>

    <?php else: ?>
        <p class="empty-message">Your cart is empty.</p>
    <?php endif; ?>
</div>

</body>
</html>
