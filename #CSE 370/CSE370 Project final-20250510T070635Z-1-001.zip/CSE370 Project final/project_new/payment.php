<?php
session_start();
include("connect.php");

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$user_email = $_SESSION['email'];
$success = "";

// Function to generate a unique transaction ID
function generateTransactionID() {
    return 'TXN' . strtoupper(uniqid());
}

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = $_POST['phone'];
    $payment_method = $_POST['payment_method'];
    $transaction_id = generateTransactionID();
    $date = date("Y-m-d H:i:s");
    $payment_status = "Successful";

    if (!empty($phone) && !empty($payment_method)) {
        // Prepare the insert statement for payment
        $stmt = $conn->prepare("INSERT INTO payment (user_email, phone, transaction_id, payment_method, payment_status, time) VALUES (?, ?, ?, ?, ?, ?)");
        
        // Check if the statement was prepared successfully
        if ($stmt === false) {
            die('MySQL prepare error: ' . $conn->error);
        }

        // Bind parameters
        $stmt->bind_param("ssssss", $user_email, $phone, $transaction_id, $payment_method, $payment_status, $date);

        // Execute the query
        if ($stmt->execute()) {
            // Get the cart items
            $cart_query = mysqli_query($conn, "
                SELECT cart.quantity, products.product_name, products.price
                FROM cart
                JOIN products ON cart.product_id = products.id
                WHERE cart.user_email = '$user_email'
            ");

            // Insert order history
            while ($row = mysqli_fetch_assoc($cart_query)) {
                $product_name = $row['product_name'];
                $quantity = $row['quantity'];
                $total_price = $row['price'] * $quantity;

                // Insert each product into the order history
                $insert_history = $conn->prepare("INSERT INTO order_history (user_email, product_name, quantity, total_price, transaction_id) VALUES (?, ?, ?, ?, ?)");

                // Check if the history insert statement was prepared successfully
                if ($insert_history === false) {
                    die('MySQL prepare error: ' . $conn->error);
                }

                // Bind parameters for history insertion
                $insert_history->bind_param("ssids", $user_email, $product_name, $quantity, $total_price, $transaction_id);
                $insert_history->execute();
                $insert_history->close();
            }

            // Clear the cart after successful payment
            mysqli_query($conn, "DELETE FROM cart WHERE user_email = '$user_email'");

            $success = "✅ Payment Successful! Transaction ID: $transaction_id";
        } else {
            $success = "❌ Payment Failed. Please try again.";
        }

        // Close the statement
        $stmt->close();
    } else {
        $success = "❌ All fields are required.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f9fafb;
            padding: 50px;
            margin: 0;
        }

        .payment-container {
            max-width: 600px;
            margin: auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
        }

        h2 {
            text-align: center;
            color: #111827;
        }

        label {
            font-weight: bold;
            margin-top: 15px;
            display: block;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
        }

        .submit-btn {
            width: 100%;
            margin-top: 25px;
            background-color: #10b981;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #059669;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
            text-decoration: none;
            color: #2563eb;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="payment-container">
    <h2>Complete Your Payment</h2>

    <form method="POST" action="payment.php">
        <label>Email:</label>
        <input type="email" value="<?php echo $user_email; ?>" readonly>

        <label>Phone Number <span style="color:red">*</span></label>
        <input type="text" name="phone" required>

        <label>Payment Method <span style="color:red">*</span></label>
        <select name="payment_method" required>
            <option value="">--Select Method--</option>
            <option value="Bkash">Bkash</option>
            <option value="Visa Card">Visa Card</option>
            <option value="Cash on Delivery">Cash on Delivery</option>
        </select>

        <button type="submit" class="submit-btn">Confirm Payment</button>
    </form>

    <?php if (!empty($success)): ?>
        <div class="message <?php echo strpos($success, 'Successful') !== false ? 'success' : 'error'; ?>">
            <?php echo $success; ?>
        </div>
        <?php if (strpos($success, 'Successful') !== false): ?>
            <a href="homepage.php" class="back-link">← Back to Homepage</a>
        <?php endif; ?>
    <?php endif; ?>
</div>

</body>
</html>
