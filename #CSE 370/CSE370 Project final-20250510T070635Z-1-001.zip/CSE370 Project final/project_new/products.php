<?php
session_start();
include("connect.php");

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$email = $_SESSION['email'];
$msg = '';

// Handle product posting
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $phone = $_POST['phone'];
    $description = $_POST['description'];
    $category = $_POST['category'];

    // Handle image upload
    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $image_path = $target_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $image_path);
    }

    $stmt = $conn->prepare("INSERT INTO products (user_email, product_name, price, phone, description, category, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdssss", $email, $product_name, $price, $phone, $description, $category, $image_path);
    $stmt->execute();

    $msg = "Product posted successfully!";
}

// Fetch order history
$order_query = "SELECT * FROM order_history WHERE user_email = '$email' ORDER BY payment_date DESC";
$order_result = mysqli_query($conn, $order_query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post a Product & View Order History</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
            padding: 20px;
            color: #333;
        }

        h2 {
            color: #00684a;
            text-align: center;
            margin-bottom: 20px;
        }

        .msg {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
        }

        .form-container input, .form-container textarea, .form-container select, .form-container button {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .form-container input[type="file"] {
            padding: 8px;
            border: 1px solid #ccc;
        }

        .form-container input[type="text"], .form-container input[type="number"], .form-container select {
            background-color: #fafafa;
        }

        .form-container button {
            background-color: #00684a;
            color: white;
            border: none;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-container button:hover {
            background-color: #004f36;
        }

        .history-table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
        }

        .history-table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #10b981;
            color: white;
        }

        .back-btn {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #2563eb;
            font-weight: bold;
        }

        .back-btn:hover {
            text-decoration: underline;
        }

        .history-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #2563eb;
            font-weight: bold;
        }

        .history-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h2>Post a Product</h2>

<?php if ($msg): ?>
    <div class="msg"><?php echo $msg; ?></div>
<?php endif; ?>

<div class="form-container">
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="product_name" placeholder="Product Name" required><br><br>
        <input type="number" step="0.01" name="price" placeholder="Price" required><br><br>
        <input type="text" name="phone" placeholder="Phone Number" required><br><br>
        <textarea name="description" placeholder="Description" required></textarea><br><br>
        <select name="category" required>
            <option value="">Select Category</option>
            <option value="Electronics">Electronics</option>
            <option value="Vehicles">Vehicles</option>
            <option value="Home & Living">Home & Living</option>
            <option value="Clothing">Clothing</option>
            <option value="Books">Books</option>
        </select><br><br>
        <input type="file" name="image" accept="image/*" required><br><br>
        <button type="submit">Post Product</button>
    </form>
</div>

<a class="back-btn" href="homepage.php">&larr; Back to Homepage</a>

<a class="history-link" href="#order-history">View Order History</a>

<h2 id="order-history">Your Order History</h2>

<?php if (mysqli_num_rows($order_result) > 0): ?>
    <table class="history-table">
        <tr>
            <th>Product ID</th>
            <th>Quantity</th>
            <th>Total Price</th>
            <th>Payment Method</th>
            <th>Payment Status</th>
            <th>Transaction ID</th>
            <th>Payment Date</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($order_result)): ?>
            <tr>
                <td><?php echo $row['product_id']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td><?php echo $row['total_price']; ?></td>
                <td><?php echo $row['payment_method']; ?></td>
                <td><?php echo $row['payment_status']; ?></td>
                <td><?php echo $row['transaction_id']; ?></td>
                <td><?php echo $row['payment_date']; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>No orders found.</p>
<?php endif; ?>

</body>
</html>
