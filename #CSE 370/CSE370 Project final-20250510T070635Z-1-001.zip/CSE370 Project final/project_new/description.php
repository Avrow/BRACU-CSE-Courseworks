<?php
session_start();
include("connect.php");

// Check for valid product ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid product ID.";
    exit();
}

$product_id = intval($_GET['id']);
$query = mysqli_query($conn, "SELECT * FROM products WHERE id = $product_id");

if (!$query) {
    die("Database query failed: " . mysqli_error($conn));
}

$product = mysqli_fetch_assoc($query);
if (!$product) {
    echo "Product not found.";
    exit();
}

// Get seller's name
$user_query = mysqli_query($conn, "SELECT firstName, lastName FROM users WHERE email = '{$product['user_email']}'");
$user = mysqli_fetch_assoc($user_query);

$posted_by = $user ? $user['firstName'] . " " . $user['lastName'] : "Unknown Seller";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $product['product_name']; ?> | Description</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0fdf4;
            margin: 0;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }

        .product-details-container {
            background-color: #ffffff;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            display: flex;
            flex-direction: row;
            max-width: 1000px;
            width: 100%;
            overflow: hidden;
        }

        .product-image {
            flex: 1;
            background-color: #ecfdf5;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .product-image img {
            max-width: 100%;
            max-height: 500px;
            object-fit: cover;
            border-radius: 10px;
            margin: 20px;
        }

        .product-info {
            flex: 1;
            padding: 30px;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .product-info h1 {
            margin: 0;
            font-size: 28px;
            color: #065f46;
        }

        .price {
            font-size: 22px;
            color: #10b981;
            font-weight: bold;
        }

        .posted-by {
            font-size: 16px;
            color: #0f766e;
            font-weight: 600;
        }

        .phone,
        .category,
        .description {
            font-size: 15px;
            color: #444;
        }

        .add-to-cart-btn {
            margin-top: 20px;
            background-color: #10b981;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .add-to-cart-btn:hover {
            background-color: #059669;
        }

        @media (max-width: 768px) {
            .product-details-container {
                flex-direction: column;
            }

            .product-image img {
                max-height: 300px;
            }
        }
    </style>
</head>
<body>

<div class="product-details-container">
    <div class="product-image">
        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['product_name']; ?>">
    </div>
    <div class="product-info">
        <h1><?php echo $product['product_name']; ?></h1>
        <p class="price">৳<?php echo $product['price']; ?></p>
        <p class="posted-by"> Posted by: <?php echo $posted_by; ?></p>
        <p class="phone">📞 <?php echo $product['phone']; ?></p>
        <p class="category">📂 Category: <?php echo $product['category']; ?></p>
        <p class="description"><?php echo $product['description']; ?></p>

        <form method="POST" action="homepage.php">
            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
            <button type="submit" class="add-to-cart-btn">Add to Cart</button>
        </form>
    </div>
</div>

</body>
</html>
