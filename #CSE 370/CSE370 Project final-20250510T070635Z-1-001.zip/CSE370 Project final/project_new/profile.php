<?php
session_start();
include("connect.php");

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$email = $_SESSION['email'];
$msg = "";
$passMsg = "";

// Profile Update
if (isset($_POST['update'])) {
    $fName = $_POST['fName'];
    $lName = $_POST['lName'];
    $phone = $_POST['phone'];
    $zip = $_POST['zip'];
    $houseNo = $_POST['houseNo'];
    $blockNo = $_POST['blockNo'];
    $road = $_POST['road'];

    $update = "UPDATE users SET 
        firstName='$fName', lastName='$lName', phone='$phone',
        zip='$zip', houseNo='$houseNo', blockNo='$blockNo', road='$road'
        WHERE email='$email'";
        
    if (mysqli_query($conn, $update)) {
        $msg = "Profile updated successfully.";
    } else {
        $msg = "Update failed: " . mysqli_error($conn);
    }
}

// Password Change
if (isset($_POST['changePass'])) {
    $currentPass = $_POST['currentPassword'];
    $newPass = $_POST['newPassword'];
    $confirmPass = $_POST['confirmPassword'];

    $query = mysqli_query($conn, "SELECT password FROM users WHERE email='$email'");
    $row = mysqli_fetch_assoc($query);

    if ($currentPass !== $row['password']) {
        $passMsg = "Current password is incorrect.";
    } elseif ($newPass !== $confirmPass) {
        $passMsg = "New passwords do not match.";
    } else {
        $updatePass = "UPDATE users SET password='$newPass' WHERE email='$email'";
        if (mysqli_query($conn, $updatePass)) {
            $passMsg = "Password changed successfully.";
        } else {
            $passMsg = "Password update failed.";
        }
    }
}

// Delete account
if (isset($_POST['delete'])) {
    $delete = "DELETE FROM users WHERE email='$email'";
    mysqli_query($conn, $delete);
    session_destroy();
    header("Location: index.php");
    exit();
}

$query = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
$user = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <style>
        body {
            font-family: Arial;
            background: #f7f7f7;
            padding: 20px;
        }

        .container {
            background: white;
            padding: 30px;
            max-width: 500px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="tel"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        .btn {
            padding: 10px 20px;
            margin-top: 15px;
            cursor: pointer;
        }

        .btn-update {
            background: #28a745;
            color: white;
            border: none;
        }

        .btn-delete {
            background: #dc3545;
            color: white;
            border: none;
        }

        .btn-pass {
            background: #007bff;
            color: white;
            border: none;
        }

        .msg {
            color: green;
            text-align: center;
        }

        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>My Profile</h2>
        <?php if ($msg) echo "<p class='msg'>$msg</p>"; ?>
        <form method="post">
            <label for="fName">First Name</label>
            <input type="text" id="fName" name="fName" value="<?= $user['firstName'] ?>" required>

            <label for="lName">Last Name</label>
            <input type="text" id="lName" name="lName" value="<?= $user['lastName'] ?>" required>

            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone" value="<?= $user['phone'] ?>" required>

            <label for="zip">Zip Code</label>
            <input type="text" id="zip" name="zip" value="<?= $user['zip'] ?>" required>

            <label for="houseNo">House Number</label>
            <input type="text" id="houseNo" name="houseNo" value="<?= $user['houseNo'] ?>" required>

            <label for="blockNo">Block Number</label>
            <input type="text" id="blockNo" name="blockNo" value="<?= $user['blockNo'] ?>" required>

            <label for="road">Road Number</label>
            <input type="text" id="road" name="road" value="<?= $user['road'] ?>" required>

            <button type="submit" name="update" class="btn btn-update">Update Profile</button>
            <button type="submit" name="delete" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete your account?');">Delete Account</button>
        </form>
    </div>

    <div class="container">
        <h2>Change Password</h2>
        <?php if ($passMsg) echo "<p class='error'>$passMsg</p>"; ?>
        <form method="post">
            <label for="currentPassword">Current Password</label>
            <input type="password" id="currentPassword" name="currentPassword" required>

            <label for="newPassword">New Password</label>
            <input type="password" id="newPassword" name="newPassword" required>

            <label for="confirmPassword">Confirm New Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" required>

            <button type="submit" name="changePass" class="btn btn-pass">Change Password</button>
        </form>
    </div>

</body>
</html>
