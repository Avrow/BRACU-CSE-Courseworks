<?php
session_start();
include("connect.php");

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$email = $_SESSION['email'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'"));

// Send message
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['receiver_email']) && isset($_POST['message'])) {
    $receiver_email = mysqli_real_escape_string($conn, $_POST['receiver_email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    if ($message !== "") {
        mysqli_query($conn, "INSERT INTO chat_messages (sender_email, receiver_email, message, status) VALUES ('$email', '$receiver_email', '$message', 'unread')");
    }
}

// Fetch users
$users_result = mysqli_query($conn, "SELECT DISTINCT email FROM users WHERE email != '$email'");
$receiver_email = $_GET['receiver'] ?? '';
$chat = [];

if ($receiver_email) {
    // Mark all messages from receiver to current user as read
    mysqli_query($conn, "UPDATE chat_messages SET status = 'read' WHERE sender_email = '$receiver_email' AND receiver_email = '$email' AND status = 'unread'");

    // Fetch chat history
    $stmt = mysqli_prepare($conn, "SELECT * FROM chat_messages WHERE (sender_email = ? AND receiver_email = ?) OR (sender_email = ? AND receiver_email = ?) ORDER BY timestamp ASC");
    mysqli_stmt_bind_param($stmt, "ssss", $email, $receiver_email, $receiver_email, $email);
    mysqli_stmt_execute($stmt);
    $chat_result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($chat_result)) {
        $chat[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Eco Trade - Chat</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0fdf4;
        }

        .container {
            display: flex;
            height: 100vh;
        }

        .users {
            width: 25%;
            background-color: #d1fae5;
            border-right: 1px solid #ccc;
            overflow-y: auto;
        }

        .users h3 {
            padding: 20px;
            margin: 0;
            background-color: #065f46;
            color: white;
        }

        .users a {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid #ccc;
            color: #065f46;
            text-decoration: none;
        }

        .users a:hover {
            background-color: #bbf7d0;
        }

        .badge {
            background-color: red;
            color: white;
            font-size: 12px;
            padding: 3px 8px;
            border-radius: 50%;
            margin-left: 8px;
        }

        .chat-box {
            width: 75%;
            display: flex;
            flex-direction: column;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #065f46;
            color: white;
            padding: 15px 20px;
        }

        .top-bar .chat-title {
            font-weight: bold;
        }

        .top-bar .home-button {
            background-color: white;
            color: #065f46;
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .top-bar .home-button:hover {
            background-color: #d1fae5;
        }

        .messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background-color: #ecfdf5;
        }

        .message {
            margin-bottom: 10px;
            max-width: 60%;
            padding: 10px 15px;
            border-radius: 10px;
            clear: both;
        }

        .sent {
            background-color: #10b981;
            color: white;
            margin-left: auto;
        }

        .received {
            background-color: #d1fae5;
            color: #065f46;
            margin-right: auto;
        }

        .chat-form {
            display: flex;
            padding: 15px;
            border-top: 1px solid #ccc;
            background-color: white;
        }

        .chat-form input[type="text"] {
            flex: 1;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .chat-form button {
            background-color: #10b981;
            color: white;
            border: none;
            padding: 10px 15px;
            margin-left: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        .chat-form button:hover {
            background-color: #059669;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="users">
        <h3>Chats</h3>
        <?php while ($u = mysqli_fetch_assoc($users_result)): ?>
            <?php
                $sender = $u['email'];
                $count_result = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM chat_messages WHERE sender_email = '$sender' AND receiver_email = '$email' AND status = 'unread'");
                $count_data = mysqli_fetch_assoc($count_result);
                $unread_count = $count_data['cnt'];
            ?>
            <a href="chat.php?receiver=<?php echo $sender; ?>">
                <span><?php echo $sender; ?></span>
                <?php if ($unread_count > 0): ?>
                    <span class="badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        <?php endwhile; ?>
    </div>

    <div class="chat-box">
        <div class="top-bar">
            <div class="chat-title">
                <?php if ($receiver_email): ?>
                    Chat with <?php echo htmlspecialchars($receiver_email); ?>
                <?php else: ?>
                    Select a user to start chatting
                <?php endif; ?>
            </div>
            <a class="home-button" href="homepage.php">🏠 Home</a>
        </div>

        <?php if ($receiver_email): ?>
            <div class="messages" id="chat-box">
                <?php foreach ($chat as $msg): ?>
                    <div class="message <?php echo ($msg['sender_email'] === $email) ? 'sent' : 'received'; ?>">
                        <?php echo htmlspecialchars($msg['message']); ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <form class="chat-form" method="POST">
                <input type="hidden" name="receiver_email" value="<?php echo htmlspecialchars($receiver_email); ?>">
                <input type="text" name="message" placeholder="Type your message..." required>
                <button type="submit">Send</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
    // Auto scroll to bottom
    const chatBox = document.getElementById("chat-box");
    if (chatBox) {
        chatBox.scrollTop = chatBox.scrollHeight;
    }
</script>

</body>
</html>
