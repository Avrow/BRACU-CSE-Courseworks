<?php
session_start();
include("connect.php");

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$email = $_SESSION['email'];
$query = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
$user = mysqli_fetch_assoc($query);

// Add to cart logic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);
    $check = mysqli_query($conn, "SELECT * FROM cart WHERE user_email = '$email' AND product_id = $product_id");
    if (mysqli_num_rows($check) > 0) {
        mysqli_query($conn, "UPDATE cart SET quantity = quantity + 1 WHERE user_email = '$email' AND product_id = $product_id");
    } else {
        mysqli_query($conn, "INSERT INTO cart (user_email, product_id, quantity) VALUES ('$email', $product_id, 1)");
    }
    header("Location: homepage.php");
    exit();
}

// Category filter
$category_filter = isset($_GET['category']) ? $_GET['category'] : '';
$category_sql = ($category_filter && $category_filter !== 'All') ? "WHERE category = '" . mysqli_real_escape_string($conn, $category_filter) . "'" : "";
$products = mysqli_query($conn, "SELECT * FROM products $category_sql ORDER BY id DESC");

// Cart count
$cart_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM cart WHERE user_email = '$email'"))['count'];

// Get unread message count
$result = mysqli_query($conn, "SELECT COUNT(*) as unread_total FROM chat_messages WHERE receiver_email = '$email' AND status = 'unread'");
$data = mysqli_fetch_assoc($result);
$unread_count = $data['unread_total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Eco Trade - Homepage</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0fdf4;
        }

        .navbar {
            background-color: #065f46;
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .navbar img {
            border-radius: 8px;
        }

        .navbar input[type="text"] {
            padding: 8px;
            border-radius: 5px;
            border: none;
            width: 250px;
        }

        .nav-links a {
            color: white;
            margin: 0 12px;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
        }

        .nav-links a:hover {
            text-decoration: underline;
        }

        .cart-count {
            background-color: red;
            color: white;
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 50%;
            position: absolute;
            top: -5px;
            right: -8px;
        }

        .welcome {
            padding: 20px;
            font-size: 20px;
            font-weight: bold;
            color: #064e3b;
        }

        .categories {
            display: flex;
            gap: 15px;
            padding: 0 20px 20px;
            flex-wrap: wrap;
        }

        .category-card {
            background-color: #d1fae5;
            padding: 10px 20px;
            border-radius: 20px;
            font-weight: bold;
            color: #065f46;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .category-card:hover {
            background-color: #34d399;
        }

        .ads {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .ad-card {
            background-color: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            max-width: 350px;
            margin: 0 auto;
        }

        .ad-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .ad-card img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .ad-card:hover img {
            transform: scale(1.05);
        }

        .ad-card .info {
            padding: 20px;
        }

        .ad-card .info h3 {
            font-size: 1.2em;
            color: #065f46;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .ad-card .info .price {
            font-size: 1.1em;
            color: #10b981;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .ad-card .info .category {
            font-size: 0.9em;
            color: #888;
            margin-bottom: 10px;
        }

        .ad-card form {
            margin-top: 15px;
        }

        .ad-card button {
            background-color: #10b981;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .ad-card button:hover {
            background-color: #059669;
        }

        .ad-card button:active {
            background-color: #047857;
        }

        .footer {
            background-color: #064e3b;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 20px;
        }

        @media screen and (max-width: 768px) {
            .ads {
                grid-template-columns: 1fr;
            }

            .navbar {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }

            .nav-links {
                display: flex;
                flex-direction: row;
                flex-wrap: wrap;
                gap: 10px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<div class="navbar">
    <div style="display: flex; align-items: center; gap: 10px;">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0MrE3VsMrnAHV17UrU4-PnxeopSaFPRVbIg&s" alt="Eco Trade Logo" width="50" height="50">
        <div>
            <div style="font-size: 20px; font-weight: bold;">Eco Trade</div>
            <div style="font-size: 13px;">Buy and Sell Used Goods</div>
        </div>
    </div>

    <input type="text" placeholder="Search products, categories...">

    <div class="nav-links">
        <a href="products.php"><i class="fas fa-plus-circle"></i> Seller</a>
        <a href="cart.php" title="Cart" style="position: relative;">
            <i class="fas fa-shopping-cart"></i>
            <span>Cart</span>
            <?php if ($cart_count > 0): ?>
                <span class="cart-count"><?php echo $cart_count; ?></span>
            <?php endif; ?>
        </a>
        <a href="order_history.php"><i class="fas fa-clock-rotate-left"></i> Orders</a>
        <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
        <a href="chat.php" style="position: relative; text-decoration: none; color: white; font-weight: bold;">
            <i class="fas fa-comments"></i> Chat
            <?php if ($unread_count > 0): ?>
                <span style="
                    position: absolute;
                    top: -5px;
                    right: -10px;
                    background: red;
                    color: white;
                    border-radius: 50%;
                    padding: 2px 6px;
                    font-size: 12px;
                ">
                    <?php echo $unread_count; ?>
                </span>
            <?php endif; ?>
        </a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<div class="welcome">
    Welcome, <?php echo $user['firstName'] . " " . $user['lastName']; ?> 👋
</div>

<div class="categories">
    <?php
    $categories = ['All', 'Electronics', 'Vehicles', 'Home & Living', 'Clothing', 'Books'];
    foreach ($categories as $cat) {
        $active = ($category_filter === $cat) ? 'style="background-color:#a7f3d0;"' : '';
        $link = ($cat === 'All') ? 'homepage.php' : 'homepage.php?category=' . urlencode($cat);
        echo "<a href='$link' class='category-card' $active>$cat</a>";
    }
    ?>
</div>

<div class="ads">
    <?php
    if (mysqli_num_rows($products) > 0) {
        while ($row = mysqli_fetch_assoc($products)) {
            echo "
            <div class='ad-card'>
                <a href='description.php?id={$row['id']}'>
                    <img src='{$row['image']}' alt='{$row['product_name']}'>
                </a>
                <div class='info'>
                    <a href='description.php?id={$row['id']}'>
                        <h3>{$row['product_name']}</h3>
                    </a>
                    <p class='price'>৳{$row['price']}</p>
                    <p>📞 {$row['phone']}</p>
                    <p class='category'>Category: {$row['category']}</p>
                    <form method='POST' action='homepage.php'>
                        <input type='hidden' name='product_id' value='{$row['id']}'>
                        <button type='submit'>Add to Cart</button>
                    </form>
                </div>
            </div>
            ";
        }
    } else {
        echo "<p style='padding:20px;'>No products found in this category.</p>";
    }
    ?>
</div>

<div class="footer">
    &copy; 2025 Eco Trade - All rights reserved.
</div>

</body>
</html>
