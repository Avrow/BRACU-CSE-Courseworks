<?php
session_start();
include("connect.php");

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$user_email = $_SESSION['email'];

// Fetch order history for the logged-in user
$query = mysqli_query($conn, "SELECT order_history.*, products.product_name, products.price, payment.payment_method
                              FROM order_history
                              JOIN products ON order_history.product_name = products.product_name
                              LEFT JOIN payment ON order_history.transaction_id = payment.transaction_id
                              WHERE order_history.user_email = '$user_email'
                              ORDER BY order_history.id DESC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order History</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 50px;
        }

        .order-history-container {
            max-width: 900px;
            margin: auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        h2 {
            text-align: center;
            color: #333;
            font-size: 28px;
            margin-bottom: 30px;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            transition: background-color 0.3s ease;
        }

        .order-item:hover {
            background-color: #f4f7fc;
        }

        .order-info {
            flex: 1;
            font-size: 16px;
            color: #333;
        }

        .order-info .product-name {
            font-weight: bold;
            font-size: 18px;
            color: #065f46;
        }

        .order-info span {
            display: block;
            margin-top: 8px;
        }

        .order-price {
            font-size: 18px;
            color: #10b981;
            font-weight: bold;
            text-align: right;
        }

        .payment-method {
            color: #2563eb;
            font-size: 14px;
            margin-top: 8px;
        }

        .transaction-id {
            color: #6b7280;
            font-size: 14px;
        }

        .empty-message {
            text-align: center;
            font-size: 18px;
            color: #777;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
            text-decoration: none;
            color: #2563eb;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="order-history-container">
    <h2>Your Order History</h2>

    <?php if (mysqli_num_rows($query) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($query)): ?>
            <div class="order-item">
                <div class="order-info">
                    <span class="product-name"><?php echo $row['product_name']; ?></span>
                    <span>Quantity: <?php echo $row['quantity']; ?></span>
                    <span class="payment-method">Payment Method: <?php echo $row['payment_method']; ?></span>
                    <span class="transaction-id">Transaction ID: <?php echo $row['transaction_id']; ?></span>
                </div>
                <div class="order-price">
                    ৳<?php echo $row['total_price']; ?>
                </div>
            </div>
        <?php endwhile; ?>

    <?php else: ?>
        <p class="empty-message">You have no order history.</p>
    <?php endif; ?>

    <a href="homepage.php" class="back-link">← Back to Homepage</a>
</div>

</body>
</html>
